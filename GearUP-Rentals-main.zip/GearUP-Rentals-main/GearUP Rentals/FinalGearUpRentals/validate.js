//Title: VALIDATE.JS
//Author: Ihor Antonov
//Student ID: C00291296
//Date: 14/12/2023


//this code is taken from the semester exam code
function validate() {
    return confirm("Are you sure you want to add the details? (Y/N)")
}