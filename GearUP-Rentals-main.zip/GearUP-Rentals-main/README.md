# GearUP-Rentals
A sophomore-year team project about an equipment hire website.
